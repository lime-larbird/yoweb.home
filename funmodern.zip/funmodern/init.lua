minetest.register_node("funmodern:diamond_wood", {
    description = "Diamond Wood Planks",
    tiles = {"diamond_wood.png"},
    groups = {choppy = 1, oddly_breakable_by_hand = 3, wood = 1},
})

minetest.register_node("funmodern:mese_wood", {
    description = "Mese Wood Planks",
    tiles = {"mese_wood.png"},
    groups = {choppy = 1, oddly_breakable_by_hand = 3, wood = 1},
    light_source = 20,  -- Adjust the light level as needed
})

minetest.register_node("funmodern:copper_wood", {
    description = "Copper Wood Planks",
    tiles = {"copper_wood.png"},
    groups = {choppy = 1, oddly_breakable_by_hand = 3, wood = 1},
})

local timer = 0
local interval = 120 -- interval in seconds

minetest.register_globalstep(function(dtime)
    timer = timer + dtime
    if timer >= interval then
        -- Reset the timer
        timer = 0
        
        -- Send a random message to all players
        local messages = {
            "[Tip] You can go to spawn by saying /spawn",
            "[Tip] You can set your home position by saying /sethome and go back to that position by saying /home",
            "[Rule] Don't you dare to grief or else you will be banned",
            "[Rule] Do not say bad words",
            "[Tip] If you will see bad players or bugs, please report that to admin or staff",
            "[Tip] You can change your skin in the edit skin section in inventory",
        }
        local random_index = math.random(1, #messages)
        local message = messages[random_index]
        minetest.chat_send_all(message)
    end
end)

minetest.register_on_joinplayer(function(player)
    local message = minetest.colorize("#00FF00", "[Server]") .. " " ..
                    minetest.colorize("#00FF00", "Welcome back, " .. player:get_player_name() .. "! Have fun!") ..
                    minetest.colorize("#00FFFF", "")
                    minetest.chat_send_all(message)
end)

-- Other functions and registrations...

local bad_words = {
    "fck",
    "fuck",
    "fuk",
    "FUCK",
    "FCK",
    "FUK",
    "bitch",
    "BITCH",
    "Bitch",
    "mf",
    "MF",
    "moron",
    "MORON",
    "Moron",
    "Suck",
    "suck",
    "fucker",
    "Fucker",
    "FUCKER",
    "Mf"
    -- Add more bad words as needed
}

minetest.register_on_chat_message(function(name, message)
    for _, word in ipairs(bad_words) do
        if string.find(message, word) then
            minetest.kick_player(name, "Your message contained inappropriate language.")
            minetest.chat_send_all("[Server] " .. name .. " tried to day bad words but got kicked.")
            return true -- Message was moderated, stop further processing
        end
    end
end)

local afk_players = {}

minetest.register_globalstep(function(dtime)
    for _, player in ipairs(minetest.get_connected_players()) do
        local player_name = player:get_player_name()
        local pos = player:get_pos()

        if afk_players[player_name] then
            if afk_players[player_name].x == pos.x and
               afk_players[player_name].y == pos.y and
               afk_players[player_name].z == pos.z then
                -- Player hasn't moved
                if afk_players[player_name].timer > 60 and not afk_players[player_name].afk then
                    minetest.chat_send_all("[Server] " .. player_name .. " is AFK.")
                    afk_players[player_name].afk = true
                else
                    afk_players[player_name].timer = afk_players[player_name].timer + dtime
                end
            else
                -- Player has moved, update position and reset timer
                if afk_players[player_name].afk then
                    minetest.chat_send_all("[Server] " .. player_name .. " is no longer AFK.")
                    afk_players[player_name].afk = false
                end
                afk_players[player_name] = {x = pos.x, y = pos.y, z = pos.z, timer = 0, afk = false}
            end
        else
            -- Player has just joined or moved, record position
            afk_players[player_name] = {x = pos.x, y = pos.y, z = pos.z, timer = 0, afk = false}
        end
    end
end)

minetest.register_on_placenode(function(pos, newnode, placer, oldnode, itemstack, pointed_thing)
    if newnode.name == "default:lava_source" then
        local player_name = placer:get_player_name()
        
        -- Remove the lava source node
        minetest.remove_node(pos)

        -- Send a public message
        local message = "[Server] " .. player_name .. " tried to grief, but got kicked."
        minetest.chat_send_all(message)

        -- Kick player
        minetest.kick_player(player_name, "It's not allowed to grief.")
        return true -- Cancel the node placement
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "Hello" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hello!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "hello" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hello!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "hi" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hi there!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "Hi" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hi there!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "Hey" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hey there!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "hey" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Hey there!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "Yo" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Yooooo!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_on_chat_message(function(name, message)
    if message == "yo" then
        minetest.after(0.5, function() -- Delay by 0.5 seconds
            local formatted_message = minetest.colorize("#00FF00", "[Chatbot]") .. " " .. minetest.colorize("#FFFFFF", "Yooooo!")
            minetest.chat_send_all(formatted_message)
        end)
    end
end)

minetest.register_node("funmodern:fake_lava_source", {
    description = "Fake Lava Source",
    tiles = {"default_lava.png"},
    light_source = 20,  -- Adjust the light level as needed
    groups = {stone = 1, oddly_breakable_by_hand = 3},
})

minetest.register_node("funmodern:fake_water_source", {
    description = "Fake Water Source",
    tiles = {"default_water.png"},
    groups = {stone = 1, oddly_breakable_by_hand = 3},
})
